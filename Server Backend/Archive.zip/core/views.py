# ==============================================================================
# SYSTEM: SENTINEL SERVER (STAGING)
# MODULE: views.py
# ROLE:   INTELLIGENCE CONTROLLER (V67 - OSINT SOURCE EXPANSION)
# ==============================================================================

from django.shortcuts import render
from django.http import JsonResponse
from .db_utils import get_db_handle
import google.generativeai as genai
import feedparser
import math
import json
import ssl
import datetime
import threading
import csv
import os
import time
import socket

# --- CONFIGURATION ---
GEMINI_API_KEY = 'AIzaSyC8wk8UL-BirT2OckoenrEM6-iOxsMU1jA'
POLLING_MATRIX = { 1: 1800, 2: 14400, 3: 43200, 4: 86400, 5: 345600 }
CSV_FILE_PATH = 'thailand_postal_codes_complete.csv'
OSINT_SOURCE_FILE = 'OSINT Soruces.csv' # Note: Uses user-specified filename

# --- CONCURRENCY CONTROL ---
MISSION_QUEUE = {} 

HOTZONES_DATA = [
    {'name': 'PREAH VIHEAR', 'type': 'ARTILLERY', 'lat': 14.3914, 'lon': 104.6804, 'radius': 40000},
    {'name': 'POIPET', 'type': 'MORTARS', 'lat': 13.6600, 'lon': 102.5000, 'radius': 15000},
    {'name': 'CHONG CHOM', 'type': 'ROCKETS', 'lat': 14.4300, 'lon': 103.4300, 'radius': 35000},
    {'name': 'TRAT', 'type': 'NAVAL GUNS', 'lat': 11.9600, 'lon': 102.8000, 'radius': 25000}
]

genai.configure(api_key=GEMINI_API_KEY)

# --- MODEL INITIALIZATION ---
try:
    ANALYST_MODEL = genai.GenerativeModel("gemini-3-pro-preview")
except:
    ANALYST_MODEL = genai.GenerativeModel("gemini-2.0-flash")

try:
    TRANSLATOR_MODEL = genai.GenerativeModel("gemini-2.5-flash")
except:
    TRANSLATOR_MODEL = genai.GenerativeModel("gemini-1.5-flash")

# --- GEOSPATIAL LOOKUP ---
def get_geo_from_csv(zip_code):
    try:
        if os.path.exists(CSV_FILE_PATH):
            with open(CSV_FILE_PATH, mode='r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['POSTAL_CODE'].strip() == str(zip_code):
                        return {
                            'lat': float(row['LATITUDE']),
                            'lon': float(row['LONGITUDE']),
                            'province': row['PROVINCE_ENGLISH'],
                            'district': row['DISTRICT_ENGLISH']
                        }
    except: pass
    return None

def haversine_distance(lat1, lon1, lat2, lon2):
    try:
        R = 6371 
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat/2) * math.sin(dlat/2) + \
            math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * \
            math.sin(dlon/2) * math.sin(dlon/2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        return R * c
    except: return 9999.0

# --- INTELLIGENCE GATHERING ---

def fetch_custom_osint():
    """
    Reads the user's local CSV file for extra RSS feeds.
    Columns expected: 'url', 'link', or just the first column.
    """
    aggregated_headlines = []
    if not os.path.exists(OSINT_SOURCE_FILE):
        return []

    print(f">> [INTEL] Loading Custom Sources from {OSINT_SOURCE_FILE}...")
    try:
        with open(OSINT_SOURCE_FILE, mode='r', encoding='utf-8-sig') as f:
            # Try sniffing header
            sample = f.read(1024)
            f.seek(0)
            has_header = csv.Sniffer().has_header(sample)
            
            if has_header:
                reader = csv.DictReader(f)
                urls = []
                for row in reader:
                    # Flexible column matching
                    for key in row.keys():
                        if key and key.lower() in ['url', 'link', 'source', 'feed']:
                            if row[key]: urls.append(row[key].strip())
                            break
            else:
                # No header, assume first column
                reader = csv.reader(f)
                urls = [row[0].strip() for row in reader if row]

        # Fetch Feeds (with timeout protection)
        socket.setdefaulttimeout(3) # 3s timeout per feed
        for url in urls[:10]: # Limit to top 10 sources to prevent hangs
            try:
                if not url.startswith('http'): continue
                feed = feedparser.parse(url)
                if feed.entries:
                    # Take top 3 headlines from each source
                    for entry in feed.entries[:3]:
                        aggregated_headlines.append(f"[SOURCE: {feed.feed.get('title', 'Unknown')}] {entry.title}")
            except:
                print(f">> [INTEL] Failed to fetch {url}")
                continue
                
    except Exception as e:
        print(f">> [INTEL] Error reading OSINT CSV: {e}")
        
    return aggregated_headlines

def fetch_news():
    headlines = []
    
    # 1. GOOGLE NEWS (Global Context)
    try:
        if hasattr(ssl, '_create_unverified_context'):
            ssl._create_default_https_context = ssl._create_unverified_context
        query = "Thailand Cambodia border conflict OR troop movement OR artillery OR OSINT"
        url = f"https://news.google.com/rss/search?q={query.replace(' ', '+')}&hl=en-US&gl=US&ceid=US:en"
        feed = feedparser.parse(url)
        if feed.entries:
            headlines.extend([f"[GOOGLE] {entry.title}" for entry in feed.entries[:10]])
    except:
        headlines.append("Google News unavailable.")
        
    # 2. CUSTOM OSINT (Local Context)
    custom_headlines = fetch_custom_osint()
    headlines.extend(custom_headlines)
    
    if not headlines: return "No intelligence reports available."
    return "\n".join(headlines[:25]) # Cap at 25 items

# --- WORKER: TRANSLATION ---
def run_translation_logic(zip_code, target_lang, master_data):
    try:
        db = get_db_handle()
        col = db.intel_history
        lang_name = "THAI" if target_lang == 'th' else "KHMER"
        prompt = f'''
        TRANSLATE THIS JSON REPORT TO {lang_name}.
        KEEP KEYS/NUMBERS/COORDS IDENTICAL.
        INPUT: {json.dumps(master_data)}
        '''
        resp = TRANSLATOR_MODEL.generate_content(prompt)
        cleaned = resp.text.replace('```json', '').replace('```', '').strip()
        translated_intel = json.loads(cleaned)
        
        translated_intel['zip_code'] = zip_code
        translated_intel['last_updated'] = master_data.get('last_updated')
        translated_intel['user_location'] = master_data.get('user_location')
        translated_intel['tactical_overlays'] = master_data.get('tactical_overlays')
        translated_intel['threat_distance_km'] = master_data.get('threat_distance_km')
        
        col.update_one({'zip_code': zip_code}, {'$set': {f'languages.{target_lang}': translated_intel}})
    except: pass

# --- WORKER: FULL ANALYSIS ---
def run_mission_logic(zip_code, country, geo_data, target_lang='en', device_id='unknown'):
    print(f'>> [ANALYST] Starting Analysis for {zip_code} requested by {device_id}...')
    try:
        db = get_db_handle()
        col = db.intel_history
        
        geo_info = { 
            'name': f"{geo_data['province']}, {geo_data['district']}", 
            'lat': geo_data['lat'], 
            'lon': geo_data['lon'], 
            'distance_km': 999.0, 
            'nearest_hotzone': 'None' 
        }
        
        for hz in HOTZONES_DATA:
            d = haversine_distance(geo_info['lat'], geo_info['lon'], hz['lat'], hz['lon'])
            if d < geo_info['distance_km']:
                geo_info['distance_km'] = round(d, 1)
                geo_info['nearest_hotzone'] = hz['name']

        news_text = fetch_news()
        
        # GRADUATED LOGIC (V64)
        dist = geo_info['distance_km']
        logic_directive = ""
        
        if dist < 40:
            logic_directive = "CRITICAL: TARGET IS ON THE FRONTLINE. High risk. Authorize DEFCON 1/2 if news confirms."
        elif 40 <= dist < 120:
            logic_directive = "WARNING: TARGET IS BUFFER ZONE. Risk is Missiles/Air. Limit to DEFCON 3/4 unless 'Missile' in news."
        else:
            logic_directive = "SAFE: TARGET IS REAR AREA. Force DEFCON 5 unless National Emergency."

        prompt = f'''
        ACT AS A STRATEGIC INTELLIGENCE ANALYST.
        TARGET: {geo_info['name']} (Zip: {zip_code}).
        NEAREST THREAT: {geo_info['nearest_hotzone']} ({dist} km away).
        
        INTELLIGENCE FEED (GOOGLE + CUSTOM OSINT):
        {news_text}
        
        GEOMETRY DIRECTIVE: {logic_directive}
        
        MANDATORY PROTOCOLS (V67):
        1. DEFCON SCALE: 1=War(Red), 2=Orange, 3=Yellow, 4=Green, 5=Blue(Peace).
        2. TREND: Rising/Falling/Stable.
        3. PROBABILITY: Int 0-100%. Buffer Zone must be moderate (30-50%).
        4. EVACUATION: Recommend city >50km away.
        5. SOURCES: If Custom OSINT sources are present, prioritize their reports for local context.
        
        OUTPUT JSON ONLY:
        {{
            "defcon_status": (int 1-5),
            "trend": "Rising/Falling/Stable",
            "evacuation_point": {{ "name": "City", "lat": (float), "lon": (float), "distance_km": (float), "reason": "Reason" }},
            "roads_to_avoid": ["Road A"], 
            "emergency_avoid_locations": ["Zone A"],
            "summary": ["1...", "2...", "3...", "4...", "5..."],
            "predictive": {{
                "defcon": (int),
                "trend": "Rising/Falling/Stable",
                "forecast_summary": ["1...", "2...", "3...", "4...", "5..."],
                "risk_probability": (int)
            }}
        }}
        '''
        
        resp = ANALYST_MODEL.generate_content(prompt)
        cleaned = resp.text.replace('```json', '').replace('```', '').strip()
        master_intel = json.loads(cleaned)
        
        master_intel['last_updated'] = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        master_intel['user_location'] = { 'lat': geo_info['lat'], 'lon': geo_info['lon'] }
        master_intel['tactical_overlays'] = HOTZONES_DATA
        master_intel['zip_code'] = zip_code
        master_intel['location_name'] = f"{geo_data['province']}, {geo_data['district']}"
        master_intel['threat_distance_km'] = geo_info['distance_km']

        doc = {
            'zip_code': zip_code,
            'country': country,
            'timestamp': datetime.datetime.now().isoformat(),
            'languages': { 'en': master_intel } 
        }
        col.replace_one({'zip_code': zip_code}, doc, upsert=True)
        
        if target_lang != 'en':
            run_translation_logic(zip_code, target_lang, master_intel)
            
    except Exception as e:
        print(f'>> [ANALYST] Critical Error: {e}')
    finally:
        if zip_code in MISSION_QUEUE:
            del MISSION_QUEUE[zip_code]

def home(request):
    return render(request, 'core/home.html')

def intel_api(request):
    try:
        zip_code = request.GET.get('zip', '10110')
        country = request.GET.get('country', 'TH')
        lang = request.GET.get('lang', 'en')
        device_id = request.GET.get('device_id', 'unknown_agent')
        
        geo_data = get_geo_from_csv(zip_code)
        if not geo_data:
            return JsonResponse({'status': 'error', 'message': f'Zip {zip_code} Unknown.'})
        
        db = get_db_handle()
        col = db.intel_history
        doc = col.find_one({'zip_code': zip_code})
        
        needs_refresh = False
        
        if doc:
            ts_str = doc.get('timestamp')
            base_data = doc.get('languages', {}).get('en')
            if ts_str and base_data:
                defcon = int(base_data.get('defcon_status', 5))
                last_dt = datetime.datetime.fromisoformat(ts_str)
                age = (datetime.datetime.now() - last_dt).total_seconds()
                limit = POLLING_MATRIX.get(defcon, 172800)
                if age > limit: needs_refresh = True
            else:
                needs_refresh = True
        else:
            needs_refresh = True
            
        if needs_refresh:
            if zip_code in MISSION_QUEUE:
                return JsonResponse({'status': 'calculating', 'message': 'Mission in progress (Shared)...'})
            else:
                MISSION_QUEUE[zip_code] = time.time()
                t = threading.Thread(target=run_mission_logic, args=(zip_code, country, geo_data, lang, device_id))
                t.start()
                return JsonResponse({'status': 'calculating', 'message': 'Initializing Strategic Analysis...'})
        else:
            target_data = doc.get('languages', {}).get(lang)
            if not target_data:
                base_data = doc.get('languages', {}).get('en')
                if base_data:
                    t = threading.Thread(target=run_translation_logic, args=(zip_code, lang, base_data))
                    t.start()
                    return JsonResponse({'status': 'calculating', 'message': 'Translating Intel...'})
            return JsonResponse({'status': 'success', 'data': target_data})
            
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
