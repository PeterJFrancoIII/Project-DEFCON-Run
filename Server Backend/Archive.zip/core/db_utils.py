from pymongo import MongoClient
import os

def get_db_handle():
    db_host = os.environ.get('DB_HOST', 'db')
    db_port = int(os.environ.get('DB_PORT', 27017))
    client = MongoClient(host=db_host, port=db_port, username='admin', password='secretpassword')
    return client['fpv_market']
