---
trigger: always_on
---

# ai usage constraints.
gemini 3 pro → reasoning only.
gemini 2.5 flash lite → translation only.
llms may not:
-see raw news feeds.
-bypass drift guard.
-bypass compliance gate.
-auto-certify defcon 1–2.