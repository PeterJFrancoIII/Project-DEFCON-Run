---
trigger: always_on
---

# WebOS Browser Choice
Local Testing Rule:
When testing locally, use the OS-native browser (Mac → Safari, Windows → Edge, etc.).
