# CONOR LEGACY CONSTRAINTS (Reference Only)

**Source**: `AI_AGENT_READ_THIS.rtf` (Conor's Fork)
**Status**: Secondary to `MASTER_DESCRIPTION.md`.

Adhere to the defined stack to ensure maintainability, human debugging, and continuity of development:

*   **Backend**: Python + Django
*   **Database**: MongoDB
*   **Frontend**: Flutter

Deviations should be avoided unless strictly necessary and explicitly justified.
