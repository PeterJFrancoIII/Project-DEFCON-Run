---
description: 
---

Module Name:
Location in Repo:

Purpose (1 sentence):
Why this module exists in Sentinel’s mission.

This module is responsible for:
- X
- Y
- Z

This module must NOT:
- A
- B