---
description: 
---

This module is correct when:
- It adheres to Sentinel’s schemas
- Drift is controlled
- Evidence is traceable
- No global rule is violated