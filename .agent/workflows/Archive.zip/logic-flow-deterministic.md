---
description: 
---

Step-by-step logic:
1.
2.
3.

Decision thresholds:
- If X → Y
- If uncertainty → label explicitly
- If stale/reprint → suppress escalation

Edge cases:
- Missing data
- Conflicting sources
- Restricted zones