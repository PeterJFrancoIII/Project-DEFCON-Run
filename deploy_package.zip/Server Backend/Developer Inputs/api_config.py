import os

# Gemini API Key Configuration
# You can set this via environment variable or replace the string below.
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyCSUGNabDJM36ZnEGdv_LAmR-PqpykR2ts')
